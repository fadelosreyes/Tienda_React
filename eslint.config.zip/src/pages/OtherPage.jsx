import React from 'react';
import Cart from '../components/Cart';

const OtherPage = () => {
  return (
    <div className="other-page-container">
      <div>
        <Cart />
      </div>
    </div>
  );
};

export default OtherPage;
